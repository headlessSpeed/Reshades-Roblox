Before you proceed, please remove any other shaders installations that you may have installed.

If it is not working as intended, try this:
1. Navigate to the Roblox installation directory (%UserProfile%\AppData\Local, then delete the Roblox folder and reinstall).
2. Run the setup file once more. It should solve your problem in most cases.

If you need help with anything else, join the Discord server:
https://discord.gg/FHwjM6mPzR

___________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________

(っ◔◡◔)っ ♥ Credits ♥

Shaders effects: 
https://github.com/martymcmodding/qUINT/tree/master/Shaders
https://github.com/crosire/reshade-shaders/tree/master/Shaders
https://github.com/prod80/prod80-ReShade-Repository
https://github.com/BlueSkyDefender/Depth3D
https://github.com/BlueSkyDefender/AstrayFX
https://github.com/AlucardDH/dh-reshade-shaders
https://github.com/mj-ehsan/NiceGuy-Shaders
https://github.com/rj200/Glamarye_Fast_Effects_for_ReShade

Presets/Custom ReShade config: 
Extravi 
https://www.youtube.com/c/Extravi

Setup file: 
https://github.com/sitiom

Post-processing injector:
Crosire
https://reshade.me/

Roblox FPS Unlocker: 
https://github.com/axstin/rbxfpsunlocker/releases
